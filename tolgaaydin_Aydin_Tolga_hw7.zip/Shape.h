#include <iostream>
#include <string>

using namespace std;

class shape
{
public:
	//I just write this constructor for I achieved virtual functions.
	shape(string name = "Hello I am a shape"):
		myName(name){}

	virtual float perimeter() = 0;
	virtual float area() = 0;
	virtual float volume() = 0;
	virtual string getName();

private:
	string myName;


};


string shape::getName()
{

	return myName;

}

