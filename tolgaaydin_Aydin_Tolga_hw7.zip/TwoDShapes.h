#include "Shape.h"

using namespace std;



class TwoDShapes: public shape
{
public:
	float volume();

};

float TwoDShapes::volume()
{
	return 0;
}


class rectangle:public TwoDShapes
{
public:
	rectangle(float mywidth = 0, float mylength = 0, string name = "rectangle"):
		width(mywidth), length(mylength), myName(name){}
	float perimeter();
	float area();
	string getName();
private:
	float width;
	float length;
	string myName;
	
};

string rectangle::getName()
{
	return myName;
}


float rectangle::perimeter()
{
	
	return 2*(width + length);
}

float rectangle::area()
{
	
	return width*length;
}



class ThreeDShapes: public shape
{
public:
	float perimeter();

};

float ThreeDShapes::perimeter()
{
	return 0;
}



class box: public ThreeDShapes
{
public:
	box(float mywidth = 0, float myheight = 0, float mylength = 0,string name = "Box"):
		width(mywidth), height(myheight), length(mylength), myName(name){}

	float area();
	float volume();
	string getName();

private:
	float width;
	float height;
	float length;
	string myName;

};

string box::getName()
{
	return myName;
}


float box::area()
{
	return 2*(width*length+width*height+length*height);
}

float box::volume()
{
	return width*length*height;
}




