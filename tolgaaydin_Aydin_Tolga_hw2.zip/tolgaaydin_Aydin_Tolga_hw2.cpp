///// NAME-SURNAME: TOLGA AYDIN
///// ID: 27843
///// TAKE HOME EXAM 2 FOR CS204 LESSON
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;



struct courseNode //Here is the struct from the assignment file. I just modify it with the constructor.
{
	string courseCode, courseName;
	vector<int> studentsAttendingIDs;
	courseNode * next;

	courseNode(string _courseCode, string _courseName, vector<int> _studentsAttendingIDs, courseNode * _next)
		:courseCode(_courseCode), courseName( _courseName), studentsAttendingIDs(_studentsAttendingIDs),next(_next)
	{}


};

void printIDVector(vector <int> anyvector) //This is the function I wrote for print the vector in the struct.
{
	for(int i = 0; i < anyvector.size(); i++)
	{
		cout << anyvector[i] << " ";

	}

	cout << "\n";
}



void printCourseList(courseNode * anyPtr) //I wrote this function for display the output and its utilize printIDVector function too.
{
	while (anyPtr != NULL)
	{
		cout << anyPtr->courseCode << " " << anyPtr ->courseName << ": ";
		printIDVector(anyPtr ->studentsAttendingIDs);
		anyPtr = anyPtr->next;
	}
}

void finalPrint(courseNode * anyPtr) //So this function for the final display if user select the option as 4. If course capacity is less than 3 it will print that this course will be closed.
{
	while (anyPtr != NULL)
	{
		cout << anyPtr->courseCode << " " << anyPtr ->courseName << ": ";
		if(anyPtr -> studentsAttendingIDs.size() < 3)
		{
			for(int i = 0; i < anyPtr ->studentsAttendingIDs.size(); i++)
			{
				cout << anyPtr -> studentsAttendingIDs[i] << " ";
			}

			cout << "-> This course will be closed" << endl;
			
		}
		
		else
		{
			printIDVector(anyPtr -> studentsAttendingIDs);
		}


		anyPtr = anyPtr->next;
	}

}



bool SearchList(courseNode *head, string searchValue) // I took this function from our recitation materials and modift them to our homework. It helps to create algorithms especially in if-else statements.
{
	while (head != NULL)
	{
		if(head->courseCode == searchValue) 
		
			return true;			
		head = head->next;
	}

	return false;
}

courseNode * findTheP(courseNode  *head,string searchedCourseCode) // I took this function from our recitation materials and modift them to our homework. It helped to find the vectors that will be push_backed.
{
	
	while(head != NULL)
	{
		if(head -> courseCode == searchedCourseCode)
		{
			return head;

		}

		head = head -> next;
		


	}



}

courseNode * AddInOrder(string courseCode, string courseName, int ID,courseNode *head) // I took this function from the slides of our lessons. It helped to keep the list sorted.
{

	courseNode * ptr = head;

	if(head == NULL || courseName < head -> courseName)
	{
		courseNode * temp = new courseNode(courseCode,courseName,vector<int>(),nullptr);
		temp -> studentsAttendingIDs.push_back(ID);
		return temp;

	}

	while(ptr -> next != NULL && ptr -> next -> courseName < courseName)
	{
		ptr = ptr->next;
	}

	courseNode * temp = new courseNode(courseCode,courseName,vector<int>(),nullptr);
	temp -> courseCode = courseCode;
	temp -> courseName = courseName;
	temp ->studentsAttendingIDs.push_back(ID);
	temp -> next = ptr -> next;
	ptr -> next = temp;

	return head;
}

bool searchInVector(courseNode *anyP,int ID) // This function help to if students already found in the vector to display the situation.
{
	for(int i = 0; i < anyP -> studentsAttendingIDs.size();i++)
	{
		if(anyP -> studentsAttendingIDs[i] == ID)
		{
			return true;
		}
	}

	return false;
}




void ClearList(courseNode * &head) // I took this function from our lesson slides too. So we can be sure that there will be no memory leak.
{
	courseNode *ptr;
	while(head!=NULL)
	{
		ptr=head;
		head=head->next;
		delete ptr;
	}
}



void deleteStudentID(int id, courseNode *ptr) // I took this function from our lesson slides and implement them from the choice '2' in the main program.
{

    unsigned long lastIndex = ptr->studentsAttendingIDs.size()-1;
    for(int i=0;i<ptr->studentsAttendingIDs.size();i++)
	{
        if(ptr->studentsAttendingIDs[i]==id)
		{
            while (i<lastIndex) 
			{
                ptr->studentsAttendingIDs[i] = ptr->studentsAttendingIDs[i+1];
                i++;
            }
        }
    }
    ptr->studentsAttendingIDs.pop_back();
}



int main()
{
	ifstream file;
	string fileName,line,tempCourseCode,tempCourseName;
	int tempID;

	//First I build the our head.
	courseNode * head = new courseNode("","",vector<int>(),nullptr);
	courseNode * tHead = head;
	courseNode * searchedP;


	// Then I initilized our linked list.
	cout << "Please enter file name: ";
	cin >> fileName;
	file.open(fileName.c_str());
	cout << "Successfully opened file CoursesAndStudents.txt" << endl; 

	while(!file.eof())
	{
		
		file >> tempCourseCode >> tempCourseName >> tempID;

		if(SearchList(head,tempCourseCode))
		{
			searchedP = findTheP(head,tempCourseCode);
			searchedP -> studentsAttendingIDs.push_back(tempID);
			sort(searchedP -> studentsAttendingIDs.begin(),searchedP -> studentsAttendingIDs.end());
		}
		else
		{
			AddInOrder(tempCourseCode,tempCourseName,tempID,tHead);

		}


	}


	cout << "The linked list is created. \nThe initial list is:" << endl;
	printCourseList(head->next);
	
	int choice = 0;

	// Here is the our main program and the flow. I set the choice as 0 so when user choose option as 4 the program will be stopped.
	while (choice != 4)
	{

		cout << "Please select one of the choices: " << endl;
		cout << "1. Add to List \n2. Drop from List \n3. Display List \n4. Finish Add/Drop and Exit" << endl;
		cin >> choice;


		//This is for the adding students to courses.
		if (choice == 1)
		{
			string tempString;
			

			cout << "Give the student ID and the course names and course codes that he/she wants to add: " << endl;
			
			cin.ignore();
			getline(cin,tempString);

			istringstream forRead(tempString);
			string word;
			int count = 1;
			string addCourseCode, addCourseName;
			int addID;
			while(forRead >> word)
			{
				courseNode * addedToP;

				// We know that file line will be courseCode,courseName,then ID's(dont know exactly number). So I checked the word if in between number chars it will be ID. Else It will be courseCode then courseName. To be sure that I added count too.
				if(char(word[0]) >= '0' && char(word[0]) <= '9')
				{
					addID = stoi(word);

					if(SearchList(head,addCourseCode))
					{
						addedToP = findTheP (head,addCourseCode);

						if(searchInVector(addedToP,addID))
						{
							cout << "Student with id " << addID << " already is enrolled to " << addCourseCode << ". No action taken." << endl;

						}
						else
						{
							cout <<	"Student with id " << addID << " is enrolled to " << addCourseCode << endl;							
							addedToP -> studentsAttendingIDs.push_back(addID);
							sort(addedToP ->studentsAttendingIDs.begin(),addedToP ->studentsAttendingIDs.end());
						}


					}

					else
					{
						cout << addCourseCode << " does not exist in the list of Courses. It is added up." << endl;
						cout << "Student with id " << addID << " is enrolled to " << addCourseCode << "." << endl;
						AddInOrder(addCourseCode,addCourseName,addID,head);

					}


				}
				else if(count % 2 == 1)
				{
					addCourseCode = word;
					count++;
				}

				else if(count % 2 == 0)
				{

					addCourseName = word;
					count++;
				}

			}

		}

		//This is the function for drop students from courses. It works with the same logic with the add function.
		else if (choice == 2)
		{

			string tempString;

			cout << "Give the student ID and the course names and course codes that he/she wants to drop: " << endl;
			
			cin.ignore();
			getline(cin,tempString);

			istringstream forRead(tempString);
			string word;
			int count = 1;
			string dropCourseCode, dropCourseName;
			int dropID;
			while(forRead >> word)
			{
				courseNode * dropP;

				if(char(word[0]) >= '0' && char(word[0]) <= '9')
				{
					dropID = stoi(word);

					if(SearchList(head,dropCourseCode))
					{
						dropP = findTheP (head,dropCourseCode);

						if(searchInVector(dropP,dropID))
						{
							int index = 0;

							for(int i = 0; i < dropP ->studentsAttendingIDs.size();i++)
							{
								if(dropP ->studentsAttendingIDs[i] == dropID)
								{
									index = i;
									break;
								}

							}

							cout << "Student with id " << dropID << " has dropped " << dropCourseCode << "." << endl;
							deleteStudentID(dropID,dropP);					
						}
						else
						{
							cout << "Student with id " << dropID << " is not enrolled to " << dropCourseCode << ", thus he can't drop that course." << endl;
						}


					}

					else
					{
						cout << "The " << dropCourseCode << "  course is not in the list, thus student with id " << dropID << " can't be dropped" << endl;

					}



				}
				else if(count % 2 == 1)
				{
					dropCourseCode = word;
					count++;
				}

				else if(count % 2 == 0)
				{

					dropCourseName = word;
					count++;
				}


			}

		}

		// This is the choice for printing current list. Thanks to printCourseList function it was the most simple part.
		else if (choice == 3)
		{
			printCourseList(head->next);
		}

		// This is the final choice,printing final list and exit situation from the loop.
		else if (choice == 4)
		{
			cout << "The add/drop period is finished. Printing the final list of courses and students attending them." << endl;
			cout << "NOTE: Courses with less than 3 students will be closed this semester." << endl;
			
			finalPrint(head->next);

		}


	}

	//After then print it finally we can delete them for no memory leak.
	ClearList(head);
	delete searchedP;
	delete tHead;
	delete head;
	
	return 0;
}

