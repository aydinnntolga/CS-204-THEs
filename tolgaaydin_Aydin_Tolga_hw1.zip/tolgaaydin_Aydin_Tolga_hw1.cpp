﻿// Name-Surname: Tolga Aydın 
// Student ID: 27843
// CS 204-Take Home 1

#include <iostream>
#include <vector>
#include <string>
#include "randgen.h"

using namespace std;



char countNeighbours(int row, int column,const vector<vector<char>> & mat )			//This is the function which I wrote for calculate the number of bombs in the neighbouring cells. I use char and const vector with reference for more efficiency as Artrim Hoca told.
{                                                                                   
	int numberOfBombs = 0;
	for(int x = -1; x <= 1; x++)													//The reason behind this function and this "for" loop is actually almost the same we saw in the recitation. Let's say our coordinates row=i and column =j;
	{
		for(int y = -1; y <= 1; y++)												//So neighbouring cells will be					i-1,j-1 /// i-1,j  /// i-1,j+1								
		{                                                                           //												i,j-1   /// i,j    /// i,j+1
			int newRow, newColumn = 0;												//												i+1,j-1 /// i+1,j  /// i+1,j+1
			newRow = row + x;														//So I wrote two loop which starts from -1 and goes to 1. Then add them to our coordinates.
			newColumn = column + y;

			if (x == 0 && y == 0)													// If our variables will be zero then function will be calculate the original coordinate too. (Which we don't want to see.) So I wrote this if condition.
			{
				continue;
			}

			if (newRow >= 0 && newRow <= mat.size()-1 && newColumn >= 0 && newColumn <= mat[0].size()-1) //I Think most important part in this function what if we tried to calculate corner coordinates? I checked there our new coordinates will be in the range or not.
			{
				if (mat[newRow][newColumn] == 'B')
				{
					numberOfBombs++;
				}
			}
		}
	}
	return numberOfBombs;

}

void printBoard (const vector<vector<char>> & mat ) //This is the simple function that I wrote for the print the original board. Also, the good debugger for me :). I put const vector with reference for more efficiency as Artrim Hoca told.
{
	for(int j = 0 ; j < mat.size() ; j++)
	{

		for(int k = 0 ; k < mat[0].size() ; k++)
		{

			if(mat[j][k] == 'B')
			{
				cout << mat[j][k] << "	" ; 
			}
			else if(mat[j][k] != 'B') // Due to I use char vectors, when I use countNeighbours it was printing some symbols instead of numbers so if the charachter is not bomb, it started to print integer with that.
			{
				cout << int(mat[j][k]) << "	";
			}
		}
		
		cout << endl;

	}
}


void printFakeBoard (const vector<vector<char>> & mat ) // This is the fake board which will be represented to the player with 'X' charachters. It is almost works same with the  printBoard function.
{
	for(int j = 0 ; j < mat.size() ; j++)
	{

		for(int k = 0 ; k < mat[0].size() ; k++)
		{
			if(mat[j][k] == 'X' || mat[j][k] == 'B') // When player hits the mine, I had to show the fakeBoard again so only 'B' and 'X' charachters printed with chars; other numbers printed with integers.
			{
				cout << mat[j][k] << "	" ; 
			}
			else if(mat[j][k] != 'X')
			{
				cout << int(mat[j][k]) << "	";
			}
		}
		cout << endl;
	}

}

int main()
{

	int totalRow,totalColumn,totalBomb;


	cout << "Give the dimensions of the matrix: " ;
	cin >> totalRow >> totalColumn;

	cout <<  "How many bombs: ";
	cin >> totalBomb;

	while (totalBomb >= totalRow * totalColumn || totalBomb < 1) //This is the loop where I checked 0 < 𝑛𝑟𝑀𝑖𝑛𝑒𝑠 < 𝑟𝑜𝑤 ∙ 𝑐𝑜l equilibrium.
	{
		if(totalBomb >= totalRow * totalColumn)
		{
		cout << "The number of bombs can not be greater than the whole number of cells minus one. Please give the number of bombs again: ";
		cin >> totalBomb;
		}

		if(totalBomb < 1)
		{
		cout << "The number of bombs could not be less than one. Please give the number of bombs again: ";
		cin >> totalBomb;
		}
	}


	vector<vector<char>>gameBoard(totalRow,vector<char>(totalColumn)); //Finally I created my Game Board with a char vectors.

	int winCondition = (totalRow * totalColumn) - totalBomb; // I did not want to use more than one variable for bombs. The loop below was using totalBomb variable too so. Thus, I wrote my winCondition which is the number of turns for win the game.

	RandGen rand = RandGen();

	while (totalBomb != 0)
	{

		int i = rand.RandInt(0,gameBoard.size()-1); //I get a random row from there.
		int j = rand.RandInt(0,gameBoard[0].size()-1); // I get a random column from there.

		if (gameBoard [i][j] != 'B') //I dont want to put more than one mine into one cell. So firstly I check whether the cell has a bomb.
		{
			gameBoard [i][j] = 'B'; // Then I put the bomb.
			totalBomb--;
		}
	}

	

	

	for(int i = 0; i <= gameBoard.size()-1; i++) // In this loop I tried to fill empty spaces with integers so original board initialized completely.
	{
		for(int j = 0; j <= gameBoard[0].size()-1; j++)
		{

			if(gameBoard[i][j] == 'B') // As we filled with some spaces with 'B' chars. I don't want to fill them again with numbers.
			{
				continue;
			}

			else
			{
				gameBoard[i][j] = countNeighbours(i,j,gameBoard);
			}
		}
	}


	vector<vector<char>>fakeGameBoard(totalRow,vector<char>(totalColumn,'X')); // Here is my represented board with 'X' chars.

	printBoard(gameBoard); // I just print it for the clarification.

	printFakeBoard(fakeGameBoard);




	while(winCondition != 0 ) // This is the flow of the main program actually.
	{
		string choice;
		cout << " Press: \n 1. If you want to find out the surrounding of a cell \n 2. If you want to open the cell \n 3. If you want to exit." << endl;
		cin >> choice;

		if(choice != "1" && choice != "2" && choice != "3") // Firstly I checked the choice is different from 1,2 or 3.
		{
			while (choice != "1" || choice != "2" || choice != "3" )
			{
				cout << "Your input is wrong. Please select one of the options: 1, 2 or 3." << endl;	
				cin >> choice;

				if(choice == "1" || choice == "2" || choice == "3" )
				{
					break;
				}

			}

		}

		if (choice == "1")
		{
			int selectedRow, selectedColumn = 0;
			cout << "Give the coordinates: ";
			cin >> selectedRow >> selectedColumn;


			while(selectedRow < 0 || selectedRow >= gameBoard.size()|| selectedColumn < 0 || selectedColumn >= gameBoard[0].size()) // I checked there given coordinates in the range or not.
			{
				cout << "It is out of range. Please give a valid coordinates: ";
				cin >> selectedRow >> selectedColumn;

			}

			if(fakeGameBoard[selectedRow][selectedColumn] != 'X') // Player can choose first choice as second option, then it wants to choose same coordinates with the choice 1. So, we don't need to hide same coordinates until end of the game. So, first I checked this coordinate opened in the represented board or not.
			{
				cout << "Displaying the surrounding of (" << selectedRow << "," << selectedColumn << "):" << endl;
				printFakeBoard(fakeGameBoard);
				cout << "Around (" << selectedRow << "," << selectedColumn << ") you have "<< int(fakeGameBoard[selectedRow][selectedColumn]) << " bomb(s)";
				continue;
			}

			else
			{
				fakeGameBoard[selectedRow][selectedColumn] = countNeighbours(selectedRow,selectedColumn,gameBoard); // After take the valid coordinates, I take the charachter from original to the fake board then I print it.

				cout << "Displaying the surrounding of (" << selectedRow << "," << selectedColumn << "):" << endl;
				printFakeBoard(fakeGameBoard);
				cout << "Around (" << selectedRow << "," << selectedColumn << ") you have "<< int(fakeGameBoard[selectedRow][selectedColumn]) << " bomb(s)";

			
				fakeGameBoard[selectedRow][selectedColumn] = 'X'; // After display, I close my represented board again.
			}
		}


		if (choice == "2")
		{
			int selectedRow2, selectedColumn2 = 0;
			cout << "Give the coordinates: ";
			cin >> selectedRow2 >> selectedColumn2;	

			while(selectedRow2 < 0 || selectedRow2 >= gameBoard.size()|| selectedColumn2 < 0 || selectedColumn2 >= gameBoard[0].size()) // Here again I checked the ranges of coordinates firstly.
			{
				cout << "It is out of range. Please give a valid coordinates: ";
				cin >> selectedRow2 >> selectedColumn2;

			}

			if(gameBoard[selectedRow2][selectedColumn2] == 'B') //If coordinates are valid there are two possibilities. Player will hit the mine or not. If it hits, the game need to end so firstly we need the check that.
			{
				fakeGameBoard[selectedRow2][selectedColumn2] = gameBoard[selectedRow2][selectedColumn2];
				cout << "Opening cell (" << selectedRow2 << "," << selectedColumn2 << ") :" << endl;
				printFakeBoard(fakeGameBoard);
				cout << "\n \n";
				cout << "Unfortunately, you stepped on a mine \n \n Arrangement of mines: \n";
				printBoard(gameBoard);
				cout << "\n \n \n";
				cout << ">>>>> Game Over! <<<<<" << endl;
				break;

			}
			else // If player won't hit the mine so it is clear and we can decrease our winCondition.
			{
				fakeGameBoard[selectedRow2][selectedColumn2] = gameBoard[selectedRow2][selectedColumn2];
				cout << "Opening cell (" << selectedRow2 << "," << selectedColumn2 << ") :" << endl;
				printFakeBoard(fakeGameBoard);
				winCondition--;
			}

		}

		if (choice == "3") //And here it is the final choice which led to exit the program.
		{
			cout << "Program exiting ..." << endl;
			break;

		}


	}




	if(winCondition == 0) // Lastly if player wins here it is the congratulations message.
	{
		cout << "Congratulations! All the non-mined cells opened successfully \nYou won! \n \n>>>>> Game Over! <<<<<" << endl;

	}




	return 0;
}