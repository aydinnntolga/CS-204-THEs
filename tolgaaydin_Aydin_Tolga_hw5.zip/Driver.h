#ifndef DRIVER_H
#define DRIVER_H

#include <iostream>
#include <string>
#include "Car.h"

using namespace std;

class Driver
{
	private:

		double budget;
		Car & driversCar;

	public:

		Driver(Car &,double);
		void drive(int);
		void repairCar(string);
		void display() const;
		void fullFuel();
};



#endif