#ifndef CAR_H
#define CAR_H


//Name-Surname: Tolga Ayd�n ID: 27843 CS204 TAKE HOME 5

#include <iostream>
#include <string>

using namespace std;

class Car
{
	private:
		double fuel;
		double insuranceFee;
		double totalDistance;

	public:
		
		Car(double,double,double);
		void display() const;
		double getFuel();
		void setFuel(double);
		double getFee();
		void setFee(double);
		double getDistance();
		void setDistance(double);
};



#endif