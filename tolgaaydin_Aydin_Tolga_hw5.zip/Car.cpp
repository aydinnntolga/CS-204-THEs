#include "Car.h"

Car::Car(double currentFuel, double fee, double distance)
	: fuel(currentFuel), insuranceFee(fee), totalDistance(distance)
{}

void Car::display() const
{
	cout << "Fuel level: " << fuel << endl;
	cout << "Insurance Fee: " << insuranceFee << endl;
	cout << "Total distance that the car has travelled: " << totalDistance << endl << endl;

}

double Car::getFuel()
{
	return fuel;
}

void Car::setFuel(double newFuel)
{
	fuel = newFuel;
}

double Car::getFee()
{
	return insuranceFee;
}

void Car::setFee(double newFee)
{
	insuranceFee = newFee;
}

double Car::getDistance()
{
	return totalDistance;
}

void Car::setDistance(double newDistance)
{
	totalDistance = newDistance;
}
