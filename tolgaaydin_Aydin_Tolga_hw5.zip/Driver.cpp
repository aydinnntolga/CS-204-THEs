#include "Driver.h"

Driver::Driver(Car & sharedCar,double totalBudget)
	:driversCar(sharedCar), budget(totalBudget)
{}

void Driver::drive(int km)
{
	double fuelLevel = driversCar.getFuel();
	double distanceLevel = driversCar.getDistance();

	distanceLevel += km;
	driversCar.setDistance(distanceLevel);

	fuelLevel -= km * 0.25;

	driversCar.setFuel(fuelLevel);
	
}

void Driver::repairCar(string accident)
{
	double fee = driversCar.getFee();
	if(accident == "SMALL")
	{
		double feeCost = fee * 0.05;

		fee = feeCost + fee;

		driversCar.setFee(fee);

		budget = budget - 50;

		cout << "50$ is reduced from the driver's budget because of the " << accident << " accident" << endl;
		cout << "Yearly insurance fee is increased to " << fee << " because of the " << accident << " accident" << endl;

	}

	else if(accident == "MEDIUM")
	{
		double feeCost = fee * 0.1;

		fee = feeCost + fee;

		driversCar.setFee(fee);

		budget = budget - 150;

		cout << "150$ is reduced from the driver's budget because of the " << accident << " accident" << endl;
		cout << "Yearly insurance fee is increased to " << fee << " because of the " << accident << " accident" << endl;
	}

	else if(accident == "LARGE")
	{
		double feeCost = fee * 0.2;

		fee = feeCost + fee;

		driversCar.setFee(fee);

		budget = budget - 300;

		cout << "300$ is reduced from the driver's budget because of the " << accident << " accident" << endl;
		cout << "Yearly insurance fee is increased to " << fee << " because of the " << accident << " accident" << endl;
	}

	else
	{
		cout << "There is no accident type such that " << accident << endl;
	}

}

void Driver::display() const
{
	cout << "Driver budget: " << budget << endl;
}

void Driver::fullFuel()
{
	double fuel = driversCar.getFuel();

	if(fuel > 0)
	{
		double money = 300 - fuel;

		budget -= money;

		driversCar.setFuel(300);
	}

	else
	{
		budget -= 300;
		driversCar.setFuel(300);
	}

	cout << "Fuel is full.\n" << endl;
}
