#ifndef INTQUEUE_H
#define INTQUEUE_H
#include <iostream>
#include <string>

using namespace std;

class IntQueue
{
private:
	string * queueArray;
	int queueSize;  //capacity of queue
	int front;
	int rear;
	int numItems;  //# of elements currently in the queue
public:
	IntQueue(int);  //constructor, parameter is capacity
	~IntQueue();
  	void enqueue(string,string,string); 
  	void dequeue(string &);
  	bool isEmpty() const; 
  	bool isFull() const;
  	void clear();  //removes all elements
};
#endif