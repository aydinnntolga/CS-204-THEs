#ifndef DYNQUEUE_H
#define DYNQUEUE_H
#include <string>
using namespace std;

struct QueueNode
{
	string name,function;
	int ID;
	QueueNode *next;
	QueueNode(string functionname,string nam,int nID, QueueNode *ptr = NULL)
	{
		function = functionname;
		name = nam;
		ID = nID;
		next = ptr;
	}
};

class DynQueue
{
	private:
		// These track the front and rear of the queue.
		QueueNode *front;
		QueueNode *rear;	
	public:
		// Constructor.
		DynQueue();
		~DynQueue();
		// Member functions.
		void enqueue(string,string,int);
		void dequeue(string&,string &,int &);
		bool isEmpty() const;     
		void clear();
};
#endif