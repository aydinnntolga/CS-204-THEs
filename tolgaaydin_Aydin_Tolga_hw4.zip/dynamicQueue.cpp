#include <iostream>
#include "dynamicQueue.h"
using namespace std;

//************************************************
// Constructor. Generates an empty queue         *
//************************************************
DynQueue::DynQueue()
{
	front = NULL;
	rear = NULL;   
	#ifdef _DEBUG
		cout << "An empty queue has been created\n";
	#endif
}



//********************************************
// Function enqueue inserts the value in num *
// at the rear of the queue.                 *
//********************************************
void DynQueue::enqueue(string function,string data,int ID)
{       
	if (isEmpty())   //if the queue is empty
	{	//make it the first element
		front = new QueueNode(function,data,ID);
		rear = front;
	}
	else  //if the queue is not empty
	{	//add it after rear
		rear->next = new QueueNode(function,data, ID);
		rear = rear->next;
	} 

}

//**********************************************
// Function dequeue removes the value at the   *
// front of the queue, and copies it into num. *
//**********************************************
void DynQueue::dequeue(string &function, string & name, int &ID)
{
	QueueNode *temp;
	if (isEmpty())
	{
		cout << "Attempting to dequeue on empty queue, exiting program...\n";
		exit(1);
	}
	else //if the queue is not empty
	{	//return front's value, advance front and delete old front
		function = front ->function;
		name = front->name;
		ID = front ->ID;
		temp = front;
		front = front->next;
		delete temp;      
	}
}

//*********************************************
// Function isEmpty returns true if the queue *
// is empty, and false otherwise.             *
//*********************************************
bool DynQueue::isEmpty() const
{
	if (front == NULL)
		return true;
	else 
		return false;
}

//********************************************
// Function clear dequeues all the elements  *
// in the queue.                             *
//********************************************
void DynQueue::clear()
{
	string function;
	string data; 
	int ID;

	while(!isEmpty())
		dequeue(function,data,ID); //delete all elements
	#ifdef _DEBUG
		cout << "queue cleared\n";
	#endif
}


DynQueue::~DynQueue()
{
	clear();
}