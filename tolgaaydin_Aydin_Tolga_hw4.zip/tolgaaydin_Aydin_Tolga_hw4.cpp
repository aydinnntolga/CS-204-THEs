#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "dynamicQueue.h"
#include "dynamicStack.h"
#include "staticQueue.h"


using namespace std;



///Name-Surname: Tolga Ayd�n ID: 27843 CS204 Take Home 4

//IMPORTANT NOTE BEFORE THE START: All headar files and cpp files for the stacks and queues are taken thanks to CS204 lessons and recitations. Of course they are not consisting of copies and little ---
//implementations done for the homework but for the mention where it taken from. I did not change the name of the classes so may be it helps to citate to the authors :) Cheers! ---


//First I decleared a struct for the implementation of linked list.
struct dataNode
{
	string data;
	dataNode * next;
	dataNode * under;

	dataNode(string _data, dataNode * _next, dataNode * _under)
		:data(_data),next(_next),under(_under)
	{}

};

//This is the function that I wrote for print the all linked list so everyone can see the services.
void printall(dataNode * head)
{
	dataNode * tmphead = head;
	while(head ->data != "")
	{
		while(tmphead != NULL)
		{
			cout << tmphead -> data << endl;
			tmphead = tmphead -> under;
		}
		head = head -> next;
		tmphead = head;

		cout << "\n \n";
	}

}


//This is the function for the learning the service that user wants is in the linked list or not.
bool searchTheList(dataNode *head,string data)
{
	while(head != NULL)
	{
		if(data == head ->data)
		{
			return false;
		}

		head = head -> next;
	}
	return true;
}


///This is the function for the student requests. Take the service that user want then add it to the dynamic queue.
void addStudentRequest(DynQueue &studentQueue, dataNode *head)
{
	string choice,name;
	int ID;

	cout << "Add a service <function> that the students want to use:" << endl;
	cin >> choice;

	if(searchTheList(head,choice))
	{
		cout << "The requested service function does not exist." << endl;
		cout << "GOING BACK TO MAIN MENU" <<endl;
		return;
	}

	cout << "Give student's name: ";
	cin >> name;

	cout << "Give student's ID <an int>: ";
	cin >> ID;

	studentQueue.enqueue(choice,name,ID);
	cout << name << "'s service request of " << choice << " has been put in the student's queue. \nWaiting to be served...";
	
}


//This is the instructor request for our homework since it is an array of string, I put the one string to the line (check staticQueue) then decomposed them again.
void addInstructorRequest(IntQueue &instructorQueue, dataNode *head)
{
	string choice,name,ID;
	

	cout << "Add a service <function> that the instructor want to use:" << endl;
	cin >> choice;

	if(searchTheList(head,choice))
	{
		cout << "The requested service function does not exist." << endl;
		cout << "GOING BACK TO MAIN MENU" <<endl;
		return;
	}

	cout << "Give instructor's name: ";
	cin >> name;

	cout << "Give instructor's ID <an int>: ";
	cin >> ID;

	instructorQueue.enqueue(choice,name,ID);
	cout << "Prof. " << name << "'s service request of " << choice << " has been put in the instructor's queue. \nWaiting to be served...";
	
}






// This is the function that is for the printing the stack.
void printTheStack(DynamicStringStack & originalStack)
{

	DynamicStringStack printStack = DynamicStringStack();

	if(originalStack.isEmpty())
	{
		cout << "The stack is empty." << endl;
	}

	else
	{
		string functionName,commandName,variableName;
		while(!originalStack.isEmpty())
		{
			originalStack.pop(functionName,commandName,variableName);
			printStack.push(functionName,commandName,variableName);
		}

		while(!printStack.isEmpty())
		{

			printStack.pop(functionName,commandName,variableName);
			cout << functionName << ": " << commandName << " " << variableName<< endl;
			originalStack.push(functionName,commandName,variableName);

		}

	}


}

// This is the function that helps to find the function that will serve to user.
dataNode * findTheFunction(string functionName,dataNode * head)
{
	dataNode * tmpHead = head;

	while(tmpHead != NULL)
	{
		if (tmpHead ->data == functionName)
		{
			return tmpHead;
		}

		tmpHead = tmpHead ->next;
	}

	

}

//It is the given part of the homework just made little implications by me and also changed parameters.
void processARequest(string functionName, dataNode * head, DynamicStringStack & commonStack)
{
	
	dataNode * tmpHead = findTheFunction(functionName,head);
	dataNode * underP = tmpHead ->under;
	int count = 0;
	string command,variable;

	while (underP != NULL)
	{
		string line = underP ->data;

		istringstream forRead(line);
		forRead >> command >> variable;
		
		if(command == "define")
		{
			commonStack.push(functionName, command, variable);
			count++;
		}
		else if (command == "call")
		{
		
			// the recursion goes here
			cout << "Calling " << variable << " from " << functionName << endl;
			processARequest(variable,head,commonStack);
		}
		else
		{
			cout << "PRINTING THE STACK TRACE:" << endl;
			printTheStack(commonStack);
		}

		underP = underP ->under;
	}// while
//�
	// delete this function�s data from the top of the stack
	cout<<functionName<<" is finished. Clearing the stack from it's data... " <<endl;
	while(count != 0)
	{
		commonStack.pop(functionName,command,variable);
		count--;
	}

	system("pause");
}

void processARequest(IntQueue &instructorsQueue, DynQueue &studentsQueue, dataNode * head, DynamicStringStack & commonStack)
{
	string functionName,studentName,line,instructorsID,instructorName;
	int studentID;
	if (!instructorsQueue.isEmpty())
	{
		//�
		//if instructors queue is not empty, process the next request 
		instructorsQueue.dequeue(line);
		istringstream forRead(line);
		forRead >> functionName >> instructorName >> instructorsID;
		cout << "Processing prof." << instructorName << "'s request <with ID " << instructorsID << "> of service <function>:" << endl;
		processARequest(functionName,head,commonStack);
		cout<<"GOING BACK TO MAIN MENU"<<endl;
	}
	
	else if (!studentsQueue.isEmpty())
	{
		string functionName,studentName;
		int ID;
		studentsQueue.dequeue(functionName,studentName,ID);
		cout << "Processing " << studentName << "'s request <with ID " << ID << "> of service <function>:" << endl;
		processARequest(functionName, head,commonStack);
		cout<<"GOING BACK TO MAIN MENU"<<endl;
	}
	else
	{
		// otherwise�
		cout<<"Both instructor's and student's queue is empty.\nNo request is processed."<<endl<<"GOING BACK TO MAIN MENU"<<endl;
	}
}

//Since we don't want memory leak it is for the clear single linked list.
void clearList(dataNode * head)
{
	dataNode * temp;
	while (head != nullptr)
	{
		dataNode * underP = head ->under;
		while(underP != nullptr)
		{
			temp = underP;
			underP = underP ->under;
			delete temp;
		}
		temp = head;
		head = head -> next;
		delete temp;
	}

}


int main()
{
	ifstream file;
	string fileName,choice,line;

	dataNode * head = new dataNode("",nullptr,nullptr);
	dataNode * tmpHead = head;
	dataNode * tmpUnder = head;

	DynQueue studentQueue = DynQueue(); 
	IntQueue instructorQueue = IntQueue(5);
	DynamicStringStack commonStack = DynamicStringStack();

	cout << "If you want to open a service <function> defining file, then press <Y/y> for 'yes', otherwise press any single key" << endl;
	cin >> choice;

	//While answer is Y or y continue to take inputs.
	while(choice == "Y" || choice == "y")
	{

		cout << "Enter the input file name: ";
		cin >> fileName;

		file.open(fileName.c_str());

		if(file.fail())
		{
			cout << "The file can not be opened. Exiting..." << endl;
			return 0;
		}

		else
		{

			getline(file,line);
			tmpHead ->data = line.substr(0,line.length()-1);
			tmpHead -> next = new dataNode("",nullptr,nullptr);
			tmpHead = tmpHead ->next;

			while(getline(file,line))
			{
	
					tmpUnder -> under = new dataNode(line.substr(0,line.length()-1),nullptr,nullptr);
					tmpUnder = tmpUnder -> under;				

			}

			tmpUnder = tmpHead;

		}

		file.close();

		cout << "If you want to open a service <function> defining file, then press <Y/y> for 'yes', otherwise press any single key" << endl;
		cin >> choice;
	}

//For display to what we have as services.
printall(head);






//This is the given main menu I just wrote the functions in here.
while (true){
	cout << endl;
	cout<<"**********************************************************************"<<endl
	<<"**************** 0 - EXIT PROGRAM *************"<<endl
	<<"**************** 1 - ADD AN INSTRUCTOR SERVICE REQUEST *************"<<endl
	<<"**************** 2 - ADD A STUDENT SERVICE REQUEST *************"<<endl
	<<"**************** 3 - SERVE (PROCESS) A REQUEST *************"<<endl
	<<"**********************************************************************"<<endl;
	cout << endl;
	int option;
	cout << "Pick an option from above (int number from 0 to 3): ";
	cin>>option;
	switch (option)
	{
		case 0:
			cout<<"PROGRAM EXITING ... "<<endl;
			clearList(head);
			system("pause");
			return 0;
		case 1:
			addInstructorRequest(instructorQueue,head);
			break;
		case 2:
			addStudentRequest(studentQueue,head);
			break;
		case 3:
			processARequest(instructorQueue,studentQueue,head,commonStack);
			break;
		default:
			cout<<"INVALID OPTION!!! Try again"<<endl;
	}//switch
}//while (true)

	
}
