#include <iostream>
#include "dynamicStack.h"
using namespace std;

//Constructor
DynamicStringStack::DynamicStringStack()
{
	top=NULL;
}

StackNode* DynamicStringStack::GetTopPointer(DynamicStringStack myStack)
{
	return myStack.top;
}

//Push back elements to the stack
void DynamicStringStack::push(string functionName,string commandName, string variableName)
{
	StackNode *newNode;

	newNode = new StackNode;
	newNode->function = functionName;
	newNode ->command = commandName;
	newNode ->variable = variableName;

	if(isEmpty())
	{
		top = newNode;
		newNode->next = NULL;
	}
	else
	{
		newNode->next = top;
		top = newNode;
	}
}
//Pop up elements from the stack
void DynamicStringStack::pop(string & functionName,string & commandName, string & variableName)
{
	StackNode *temp;

	if(isEmpty())
	{
		cout<<"Stack is empty!\n";
	}

	else 
	{
		functionName = top->function;
		commandName = top ->command;
		variableName = top -> variable;
		temp = top->next;
		delete top;
		top = temp;
	}
}

//If the stack is empty check function
bool DynamicStringStack::isEmpty()
{
	if(top == NULL)
		return true;
	return false;
}

void DynamicStringStack::clear()
{
	string functionName,commandName,variableName;

	while(!isEmpty())
	{
		pop(functionName,commandName,variableName);
	}

}


DynamicStringStack::~ DynamicStringStack()
{
	clear();
}
