#ifndef DYNAMICSTACK_H
#define DYNAMISTACK_H

#include <string>
using namespace std;

struct StackNode
{
	string function;
	string command;
	string variable;
	StackNode *next;
};


class DynamicStringStack
{
	private:
		StackNode *top;
		StackNode* GetTopPointer(DynamicStringStack myStack);

	public:
		DynamicStringStack(void);
		~DynamicStringStack();
		void push(string,string,string);
		void pop(string &,string &, string &);
		void clear();
		bool isEmpty(void);
};


#endif